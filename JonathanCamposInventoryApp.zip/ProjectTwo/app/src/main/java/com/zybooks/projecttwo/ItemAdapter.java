package com.zybooks.projecttwo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private List<ItemModel> itemsList;
    private Context context;

    public ItemAdapter(Context context, List<ItemModel> itemsList) {
        this.context = context;
        this.itemsList = itemsList;

    }

    public void setItems(List<ItemModel> newItemsList) {
        itemsList = newItemsList;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_data, parent, false);
        return new ViewHolder(view);
    }


    private void deleteItem(int position) {
        // Get the item to be deleted
        ItemModel deletedItem = itemsList.get(position);

        // Remove the item from the list
        itemsList.remove(position);

        // Notify the adapter about the item removal
        notifyItemRemoved(position);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ItemModel item = itemsList.get(position);

        holder.itemNameTextView.setText(item.getItemName());
        holder.itemQuantityEditText.setText(String.valueOf(item.getItemQuantity()));

        // Set click listeners for update and delete buttons
        holder.updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int newQuantity = Integer.parseInt(holder.itemQuantityEditText.getText().toString());
                item.setItemQuantity(newQuantity);
                ((GridActivity) context).updateItem(item);
            }
        });

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((GridActivity) context).deleteItem(item);

            }
        });
    }


    @Override
    public int getItemCount() {
        return itemsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView;
        EditText itemQuantityEditText;
        Button updateButton;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemQuantityEditText = itemView.findViewById(R.id.itemQuantityEditText);
            updateButton = itemView.findViewById(R.id.updateButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);

        }

    }}
