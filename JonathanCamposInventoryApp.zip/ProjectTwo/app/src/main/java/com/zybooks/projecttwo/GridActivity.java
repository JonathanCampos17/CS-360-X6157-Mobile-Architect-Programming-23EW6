package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GridActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private ItemAdapter itemAdapter;
    private RecyclerView recyclerView;

    private List<ItemModel> itemsList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        databaseHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.rvData);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve data from the database and populate the itemsList
        itemsList = retrieveDataFromDatabase();

        itemAdapter = new ItemAdapter(this, itemsList);
        recyclerView.setAdapter(itemAdapter);


        Button gearButton = findViewById(R.id.gearButton);
        gearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNotificationActivity();
            }
        });

        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddDataDialog();
            }
        });

    }


    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.add_data, null);

        final EditText editItemName = dialogView.findViewById(R.id.editItemName);
        final EditText editItemQuantity = dialogView.findViewById(R.id.editItemQuantity);

        builder.setView(dialogView);
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = editItemName.getText().toString().trim();
                int itemQuantity = Integer.parseInt(editItemQuantity.getText().toString());

                // Call the insertData method with the provided data
                insertData(itemName, itemQuantity);

                // Refresh the RecyclerView
                refreshRecyclerView();
            }
        });
        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void insertData(String itemName, int itemQuantity) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, itemQuantity);

        long newRowId = db.insert(DatabaseHelper.TABLE_ITEMS, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
            // Add the new item to the itemsList
            itemsList.add(new ItemModel(itemName, itemQuantity));
            // Refresh the RecyclerView
            itemAdapter.setItems(itemsList);
        } else {
            Toast.makeText(this, "Error inserting data", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    public void updateItem(ItemModel updatedItem) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, updatedItem.getItemQuantity());

        String whereClause = DatabaseHelper.COLUMN_ITEM_NAME + " = ?";
        String[] whereArgs = {updatedItem.getItemName()};

        int updatedRows = db.update(DatabaseHelper.TABLE_ITEMS, values, whereClause, whereArgs);

        if (updatedRows > 0) {
            Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
            // Update the itemList and refresh the RecyclerView
            for (int i = 0; i < itemsList.size(); i++) {
                if (itemsList.get(i).getItemName().equals(updatedItem.getItemName())) {
                    itemsList.get(i).setItemQuantity(updatedItem.getItemQuantity());
                    break;
                }
            }
            refreshRecyclerView();
        } else {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


    public void deleteItem(ItemModel item) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        String whereClause = DatabaseHelper.COLUMN_ITEM_NAME + " = ?";
        String[] whereArgs = {item.getItemName()};

        int deletedRows = db.delete(DatabaseHelper.TABLE_ITEMS, whereClause, whereArgs);

        if (deletedRows > 0) {
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            // Remove the item from the itemsList and update the RecyclerView
            itemsList.remove(item);
            refreshRecyclerView();
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


    private List<ItemModel> retrieveDataFromDatabase() {
        List<ItemModel> itemsList = new ArrayList<>();

        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_ITEMS,
                null, // Columns (null means all columns)
                null, // Selection
                null, // Selection arguments
                null, // Group by
                null, // Having
                null  // Order by
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                // Use the correct column names from DatabaseHelper
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));
                itemsList.add(new ItemModel(itemName, itemQuantity));
            }
            cursor.close();
        }
        db.close();
        return itemsList;
    }

    private void refreshRecyclerView() {
        List<ItemModel> newItemsList = retrieveDataFromDatabase();
        itemAdapter.setItems(newItemsList);
        itemAdapter.notifyDataSetChanged();
    }
    private void navigateToNotificationActivity() {
        Intent intent = new Intent(GridActivity.this, NotificationActivity.class);
        startActivity(intent);
    }
}